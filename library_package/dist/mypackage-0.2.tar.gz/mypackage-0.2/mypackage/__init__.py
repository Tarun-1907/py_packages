# My package is here

class mypack:
    def __init__(self):
        print("This is my constructor")
    def func(num):
        print("This is a function")
        return num