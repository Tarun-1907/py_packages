# My package is here

def func(num):
    print("This is a function")
    return num
