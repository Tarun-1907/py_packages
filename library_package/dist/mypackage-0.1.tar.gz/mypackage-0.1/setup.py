from setuptools import setup, find_packages
setup(name="mypackage",
      version="0.1",
      description="This is my package",
      long_description="This is only my package",
      author="tarun",
      packages=['mypackage'],
      install_requires=[])